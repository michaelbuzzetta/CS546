/* 
All of the functionality will be done in this client-side JS file.  
You will make client - side AJAX requests to the API and use jQuery to target and create elements on the page. You can use a client-side fetch or axios request instead of AJAX)
*/
const API_KEY = "CS546";
const BASE_URL = "http://www.omdbapi.com/";

$(document).ready(function () {
  const $searchForm = $("#searchMovieForm");
  const $searchResults = $("#searchResults");
  const $movieDetails = $("#movieDetails");
  const $rootLink = $("#rootLink");

  $searchForm.on("submit", function (event) {
    event.preventDefault();

    let searchTerm = $("#movie_search_term").val().trim();
    if (!searchTerm) {
      alert("Please enter a valid movie name!");
      return;
    }

    $searchResults.empty().hide();
    $movieDetails.empty().hide();
    $rootLink.hide();

    fetchMovies(searchTerm);
  });

  $searchResults.on("click", "a", function (event) {
    event.preventDefault();

    let movieId = $(this).data("id");
    if (!movieId) {
      alert("Invalid movie ID.");
      return;
    }

    $movieDetails.empty().hide();
    $searchResults.hide();

    fetchMovieDetails(movieId);
  });

  const fetchMovies = (searchTerm) => {
    let url = `${BASE_URL}?apikey=${API_KEY}&s=${encodeURIComponent(
      searchTerm
    )}`;
    let url2=`${BASE_URL}?apikey=${API_KEY}&s=${encodeURIComponent(searchTerm)}&page=2`;
    let output;

    $.ajax({
      url,
      method: "GET",
      success: function (data) {
        if (data.Response === "True") {
          output=data.Search;
        } else {
          alert(data.Error || "No results found.");
        }
      },
      error: function () {
        alert("An error occurred while fetching movie data.");
      },
    });
    $.ajax({
      url2,
      method: "GET",
      success: function (data) {
        if (data.Response === "True") {
          output.concat(data.search);
          displaySearchResults(output);
        } else {
          alert(data.Error || "No results found.");
        }
      },
      error: function () {
        alert("An error occurred while fetching movie data.");
      },
    })
  };

  const fetchMovieDetails = (movieId) => {
    let url = `${BASE_URL}?apikey=${API_KEY}&i=${movieId}`;

    $.ajax({
      url,
      method: "GET",
      success: function (data) {
        if (data.Response === "True") {
          displayMovieDetails(data);
        } else {
          alert(data.Error || "Could not fetch movie details.");
        }
      },
      error: function () {
        alert("An error occurred while fetching movie details.");
      },
    });
  };

  const displaySearchResults=(movies)=> {
    movies.forEach((movie) => {
      let $listItem = $(
        `<li>
                    <a href="javascript:void(0)" data-id="${movie.imdbID}">
                        ${movie.Title} (${movie.Year})
                    </a>
                </li>`
      );
      $searchResults.append($listItem);
    });

    $searchResults.show();
    $rootLink.show();
  }

  const displayMovieDetails=(movie)=> {
    let $article = $(
      `<article>
                <h1>${movie.Title || "N/A"}</h1>
                <img alt="${movie.Title} Poster" src="${
        movie.Poster !== "N/A" ? movie.Poster : "/images/no_image.jpeg"
      }">
                <h2>Plot</h2>
                <p>${movie.Plot || "N/A"}</p>
                <section>
                    <h3>Info</h3>
                    <dl>
                        <dt>Year Released:</dt>
                        <dd>${movie.Year || "N/A"}</dd>
                        <dt>Rated:</dt>
                        <dd>${movie.Rated || "N/A"}</dd>
                        <dt>Runtime:</dt>
                        <dd>${movie.Runtime || "N/A"}</dd>
                        <dt>Genre(s):</dt>
                        <dd>${movie.Genre || "N/A"}</dd>
                        <dt>Box Office Earnings:</dt>
                        <dd>${movie.BoxOffice || "N/A"}</dd>
                        <dt>DVD Release Date:</dt>
                        <dd>${movie.DVD || "N/A"}</dd>
                    </dl>
                </section>
                <section>
                    <h4>Cast and Crew</h4>
                    <p><strong>Director:</strong> ${movie.Director || "N/A"}</p>
                    <p><strong>Writer:</strong> ${movie.Writer || "N/A"}</p>
                    <p><strong>Cast:</strong> ${movie.Actors || "N/A"}</p>
                </section>
                <section>
                    <h4>Ratings</h4>
                    <table class="my_coolratings_table">
                        <tr>
                            <th>Source</th>
                            <th>Rating</th>
                        </tr>
                        ${
                          (movie.Ratings || [])
                            .map(
                              (rating) =>
                                `<tr>
                                <td>${rating.Source}</td>
                                <td>${rating.Value}</td>
                            </tr>`
                            )
                            .join("") || '<tr><td colspan="2">N/A</td></tr>'
                        }
                    </table>
                </section>
            </article>`
    );

    $movieDetails.append($article).show();
  }
});
